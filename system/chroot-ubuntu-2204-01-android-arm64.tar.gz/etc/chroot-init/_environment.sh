export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export TERM=xterm
export HOME=/root
export USER=root
export SHELL=/bin/bash
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
export PWD=/

$SHELL