#!/bin/sh
chroot . /bin/env -i /etc/chroot-init/_environment.sh

