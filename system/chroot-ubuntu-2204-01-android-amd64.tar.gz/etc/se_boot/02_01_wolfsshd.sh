#!/bin/sh

wolfsshd -f /etc/wolfsshd/sshd_config