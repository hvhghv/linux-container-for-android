# Magisk模块示例汉化版本
# 基于新的Magisk模块标准汉化（仅支持Magisk18.1及以上版本），其中`update-binary`文件供本地的个人使用或测试

# GitHub上下载后并不能直接安装至Magisk，需要把压缩包里面的文件夹里的文件提到文件夹外（即压缩包一级目录，打开压缩包无需再次打开文件夹即可看到数个文件即为成功）
  
  ！较不推荐！教程请看官方的开发者文档（下面也有），推荐大神使用，该文档思路存在一定模糊（建议先看DLGum大佬的教程），需要进阶功能者可以看（开机脚本、分区说明、提交模块至Magsik服务器等），使用网页翻译功能：https://topjohnwu.github.io/Magisk/guides.html （当然我也有翻译版）
  
  ！推荐先看！或者DLGum大佬的部分教程：https://github.com/DLGum/DLGum.github.io/commit/d3b427b821b2edc362bff11ca791983e9e52ce86 （新手友好）
  
  本人小白一枚
  
  部分翻译来自Baidu翻译和Google翻译
# 以下是官方Magisk模块示例中的README.md(已汉化）
# =分割线=

# Magisk Installer

**如果您想将模块提交到在线的模块仓库（online repo），请更新`README.md`文件！**

有关如何使用此模块安装程序的更多信息，请参阅[文档](https://topjohnwu.github.io/Magisk/guides.html)

如果您不熟悉Markdown语法，可以从Github的在线Markdown编辑器开始，该编辑器允许您在发布前预览。如果您需要更多帮助，可以使用非常方便的[Markdown备忘单](https://github.com/adam-p/markdown-here/wiki/markdown-cashtsheet)。
