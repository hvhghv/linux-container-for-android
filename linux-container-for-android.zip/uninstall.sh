#!/system/bin/sh
# 当你的模块在Magisk Manager中被删除时，下次重启执行本文件中的代码。（即执行本脚本）
# 没有特殊要求的者可以删除此文件（不明其意者亦建议删除）

rm -rf /data/linux-ubuntu